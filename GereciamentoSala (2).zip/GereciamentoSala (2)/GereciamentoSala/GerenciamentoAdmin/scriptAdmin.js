BotaoAdmin.addEventListener('click', function(event) {
    event.preventDefault(); 
    window.location.href = './telaAdmin.html'; 
});